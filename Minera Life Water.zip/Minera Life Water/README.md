# aiogram-bot-shablon
Telegramda  aiogram  orqali  bot tuzish uchun shablon

<br>
<br>

Fikr  va  mulohazalar uchun [Dasturlash bo'yicha  Foydamiz Tegsin!](https://t.me/foydamizteg_sin)



# Loyihani  yuklash

<hr>


> *$Bash*
 ![pythonanywhere](images/1.png)

<hr>


> *Loyihani  clon qiling*
 ![pythonanywhere](images/2.png)

<hr>


> *Loyihani  papkasiga kiring va __make install__*
 ![pythonanywhere](images/3.png)

<hr>


> *Rasmdagi  holat kuzatilishiga e'tibor bering*
 ![pythonanywhere](images/4.png)

<hr>


> *Shu yerda(loyiha papkasini ichida) .env fayl yarating va faylga yozish uchun nano .env buyrug'ini bering*
 ![pythonanywhere](images/5.png)

<hr>
<hr>

- .env fayl yarating va faylga env.exam faylida ko'rsatilganlarni yozing....
<br>
- PROXY_URL ga http://proxy.server:3128 ni yozing
<br>
- BOT_TOKEN ni [BotFather](https://t.me/BotFather) dan olishingiz mumkin!
<br>
- ADMINS uchun ID lar   [Get My ID](https://t.me/getmyid_bot) shu yerga yozing ID - ingizni bilishingiz mumkin
<br>
<hr>
<hr>

> *Loyihani ishga tushiring __make start__*
 ![pythonanywhere](images/6.png)

<hr>


- Mehnatimiz sizga foyda berayotgan bolsa GITHUB profilimizga obuna bo'ling va telegram kanalimizda reaksiyalarni qoldiring 👍
# *E'tiboringiz uchun rahmat* Savollaringiz bo'lsa [Telegram](https://t.me/foydamizteg_sin)
